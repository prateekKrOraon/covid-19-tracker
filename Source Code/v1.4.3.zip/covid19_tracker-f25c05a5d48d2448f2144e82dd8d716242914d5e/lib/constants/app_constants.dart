String kQuickSand = "Quicksand";
String kStalemate = "Stalemate";
String kNotoSansSc = "NotoSansSC";
String kQuickSandMedium = "QuicksandMedium";
String kOnboarding = "onboarding";
String kLangCode = "language_code";
String kCountryCode = "country_code";
String kVersion = "version";
