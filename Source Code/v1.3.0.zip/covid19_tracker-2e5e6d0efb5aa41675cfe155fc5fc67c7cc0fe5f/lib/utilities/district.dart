class District{
  String name;
  int confirmed;
  int deltaCnf;

  District(this.name, this.confirmed, this.deltaCnf);

}