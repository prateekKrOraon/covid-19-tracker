
import 'package:flutter/material.dart';

Color kPrimaryColor = Color(0xFF111111);
Color kBackgroundColor = Color(0xFF202020);
Color kAccentColor = Color(0xFFFFC107);
Color kGreenColor = Color(0xFF4CAF50);
Color kRedColor = Color(0xFFEF5350);
Color kBlueColor = Color(0xFF448AFF);
Color kGreyColor = Color(0xFF607D8B);
Color kOrangeColor = Color(0xFFFF5722);
Color kDarkBlueColor = Color(0xFF5C6BC0);
Color kCaptionColor = Colors.grey[200];
Color kGreyColorLight = Colors.grey[300];