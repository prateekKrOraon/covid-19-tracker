String kQuickSand = "Quicksand";
String kStalemate = "Stalemate";
String kNotoSansSc = "NotoSansSC";
String kQuickSandMedium = "QuicksandMedium";