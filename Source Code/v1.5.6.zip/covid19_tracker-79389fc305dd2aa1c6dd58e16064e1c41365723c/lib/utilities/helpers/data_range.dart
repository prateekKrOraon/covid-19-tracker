class DataRange{
  static const String BEGINNING = 'beginning';
  static const String MONTH = 'month';
  static const String TWO_WEEK = 'two_week';
}