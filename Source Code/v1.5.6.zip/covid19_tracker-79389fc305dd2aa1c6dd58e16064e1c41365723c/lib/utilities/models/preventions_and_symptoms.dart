class PreventionAndSymptomsModel{
  String title;
  String des;
  String que;
  String imageLoc;

  PreventionAndSymptomsModel({this.title,this.des,this.que,this.imageLoc});

}